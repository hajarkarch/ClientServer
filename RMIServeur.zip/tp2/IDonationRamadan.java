package tp2;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IDonationRamadan extends Remote {
    void ajouterDonation(double montant) throws RemoteException;
    void consulterDonations() throws RemoteException;
    double calculerTotalDonations() throws RemoteException;
}
