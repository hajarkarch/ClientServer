package tp2;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class DonationRamadanImpl extends UnicastRemoteObject implements IDonationRamadan {
    private List<Double> donations;

    public DonationRamadanImpl() throws RemoteException {
        super();
        this.donations = new ArrayList<>();
    }

    @Override
    public void ajouterDonation(double montant) throws RemoteException {
        donations.add(montant);
        System.out.println("Donation ajoutée: " + montant);
    }

    @Override
    public void consulterDonations() throws RemoteException {
        System.out.println("Liste des donations:");
        for (Double montant : donations) {
            System.out.println(montant);
        }
    }

    @Override
    public double calculerTotalDonations() throws RemoteException {
        double total = 0;
        for (Double montant : donations) {
            total += montant;
        }
        return total;
    }
}
